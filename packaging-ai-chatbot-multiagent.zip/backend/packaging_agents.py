
from langchain.agents import Tool, initialize_agent
from langchain.chat_models import ChatOpenAI
from silent_switch_agent import get_silent_switch_llm
from rag_pipeline import create_qa

llm=ChatOpenAI(temperature=0)
qa=create_qa()

def silent(q): return get_silent_switch_llm(q)
def rag(q): return qa.run(q)
def troubleshoot(q): return llm.predict("Solve packaging issue: "+q)

tools=[
 Tool(name="SilentSwitch",func=silent,description="Find silent switches"),
 Tool(name="PackagingRAG",func=rag,description="Search packaging docs"),
 Tool(name="Troubleshoot",func=troubleshoot,description="Fix install failures")
]

agent=initialize_agent(tools,llm,agent="zero-shot-react-description",verbose=True)
