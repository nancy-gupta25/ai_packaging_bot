
from fastapi import FastAPI
from pydantic import BaseModel
from packaging_agents import agent

app=FastAPI()
class Query(BaseModel): message:str

@app.post("/chat")
def chat(q:Query):
    return {"response":agent.run(q.message)}
