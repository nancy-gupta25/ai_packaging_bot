
import os
from langchain.document_loaders import PyPDFLoader,TextLoader,Docx2txtLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA

def load_docs(folder="knowledge"):
    docs=[]
    for r,_,f in os.walk(folder):
        for file in f:
            p=os.path.join(r,file)
            if file.endswith(".pdf"): docs+=PyPDFLoader(p).load()
            if file.endswith(".ps1") or file.endswith(".txt"): docs+=TextLoader(p).load()
            if file.endswith(".docx"): docs+=Docx2txtLoader(p).load()
    return docs

def create_qa():
    docs=load_docs()
    db=FAISS.from_documents(docs,OpenAIEmbeddings())
    return RetrievalQA.from_chain_type(llm=ChatOpenAI(),retriever=db.as_retriever())
