
import requests
from bs4 import BeautifulSoup
from duckduckgo_search import DDGS
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage

llm = ChatOpenAI(temperature=0)

def search_web(query, max_results=3):
    links=[]
    with DDGS() as ddgs:
        for r in ddgs.text(query, max_results=max_results):
            links.append(r["href"])
    return links

def scrape(url):
    try:
        r=requests.get(url,timeout=10)
        return BeautifulSoup(r.text,"html.parser").get_text()[:3000]
    except:
        return ""

def get_silent_switch_llm(app):
    links=search_web(app+" silent install switches")
    content="".join(scrape(l) for l in links)
    prompt=f"Extract silent install and uninstall switches from: {content}"
    return llm([HumanMessage(content=prompt)]).content
