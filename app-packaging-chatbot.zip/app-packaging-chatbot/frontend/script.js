class PackagingChatbot {
    constructor() {
        this.apiUrl = 'http://localhost:8000';
        this.initElements();
        this.initEventListeners();
    }

    initElements() {
        this.chatMessages = document.getElementById('chatMessages');
        this.userInput = document.getElementById('userInput');
        this.sendButton = document.getElementById('sendButton');
        this.webSearchCheck = document.getElementById('webSearch');
        this.ragSearchCheck = document.getElementById('ragSearch');
        this.installerType = document.getElementById('installerType');
        this.appName = document.getElementById('appName');
        this.sourcesPanel = document.getElementById('sourcesPanel');
        this.sourcesList = document.getElementById('sourcesList');
    }

    initEventListeners() {
        this.sendButton.addEventListener('click', () => this.sendMessage());
        this.userInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
    }

    async sendMessage() {
        const message = this.userInput.value.trim();
        if (!message) return;

        // Clear input
        this.userInput.value = '';

        // Add user message to chat
        this.addMessage(message, 'user');

        // Show typing indicator
        const typingIndicator = this.addTypingIndicator();

        try {
            // Prepare query
            const queryData = {
                query: message,
                use_web_search: this.webSearchCheck.checked,
                use_rag: this.ragSearchCheck.checked,
                installer_type: this.installerType.value || null,
                app_name: this.appName.value.trim() || null
            };

            // Send to API
            const response = await fetch(`${this.apiUrl}/query`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(queryData)
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();

            // Remove typing indicator
            typingIndicator.remove();

            // Add bot response
            this.addMessage(data.answer, 'bot');

            // Update sources panel
            this.updateSourcesPanel(data.sources);

        } catch (error) {
            console.error('Error:', error);
            typingIndicator.remove();
            this.addMessage('Sorry, I encountered an error. Please try again.', 'bot');
        }
    }

    addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${sender}-message`);
        
        // Format text with line breaks and bullet points
        const formattedText = text
            .split('\n')
            .map(line => {
                if (line.trim().startsWith('•')) {
                    return `<li>${line.substring(1)}</li>`;
                }
                return line;
            })
            .join('<br>');
        
        messageDiv.innerHTML = formattedText;
        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
        
        return messageDiv;
    }

    addTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.classList.add('typing-indicator');
        indicator.innerHTML = '<span></span><span></span><span></span>';
        this.chatMessages.appendChild(indicator);
        this.scrollToBottom();
        return indicator;
    }

    updateSourcesPanel(sources) {
        if (sources && sources.length > 0) {
            this.sourcesPanel.style.display = 'block';
            this.sourcesList.innerHTML = sources
                .map(source => {
                    if (source.link) {
                        return `<div class="source-item">📄 <a href="${source.link}" target="_blank">${source.title || 'Source'}</a><br><small>${source.snippet || ''}</small></div>`;
                    } else if (source.metadata) {
                        return `<div class="source-item">📁 ${source.metadata.source || 'Internal Document'}<br><small>${source.content || ''}</small></div>`;
                    }
                    return '';
                })
                .join('');
        } else {
            this.sourcesPanel.style.display = 'none';
        }
    }

    scrollToBottom() {
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PackagingChatbot();
});