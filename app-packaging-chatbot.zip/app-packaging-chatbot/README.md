# AI Packaging Chatbot

\# 3. Create virtual environment

python -m venv venv



\# 4. Activate virtual environment

.\\venv\\Scripts\\activate



\# 5. Install dependencies

pip install fastapi uvicorn python-dotenv pypdf docx2txt beautifulsoup4 requests openai chromadb langchain langchain-community langchain-openai tiktoken duckduckgo-search



\# 6. Create .env file with your API key

echo OPENAI\_API\_KEY=your-api-key-here > .env



\# 7. Create data folder and add your documents

mkdir data

\# Copy your .pdf, .txt, .docx files to data folder

pip install -U ddgs

\# 8. Start the backend server

python -m uvicorn app:app --reload --host 0.0.0.0 --port 8000



\# 9. Open new PowerShell window for frontend

\# Install http-server globally

npm install -g http-server



\# 10. Navigate to project and start frontend server

cd C:\\PackagingChatbot

http-server -p 8080



\# 11. Open browser and go to:

\# http://localhost:8080

