# backend/rag_engine.py
from typing import List, Dict, Optional
import re

class RAGEngine:
    def __init__(self):
        self.documents = []

    def load_documents(self, file_paths: Optional[List[str]] = None):
        if not file_paths:
            return
        for path in file_paths:
            self.documents.append({
                "source": path,
                "content": f"Content of {path} with example silent switches /S /quiet"
            })

    def search_documents(self, query: str) -> Dict:
        matched_docs = []
        for doc in self.documents:
            if query.lower() in doc["content"].lower():
                matched_docs.append(doc)

        sources = []
        for doc in matched_docs:
            switches = re.findall(r"(/S\b|/silent\b|/qn\b|/quiet\b|/VERYSILENT\b|/norestart\b|-silent\b|-q\b)", doc["content"], re.IGNORECASE)
            if switches:  # Only include docs with actual switches
                sources.append({
                    "title": doc.get("source", "Internal Document"),
                    "link": "",
                    "snippet": f"Silent switches found: {', '.join(switches)}"
                })

        answer = f"Found {len(sources)} document(s) with silent parameters." if sources else ""
        return {"answer": answer, "sources": sources}