import os
from typing import List, Dict
from langchain.document_loaders import (
    PyPDFLoader,
    TextLoader,
    Docx2txtLoader,
    PythonLoader
)
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
from config import Config

class RAGEngine:
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(openai_api_key=Config.OPENAI_API_KEY)
        self.llm = ChatOpenAI(
            model_name=Config.OPENAI_MODEL,
            temperature=0,
            openai_api_key=Config.OPENAI_API_KEY
        )
        self.vectorstore = None
        self.qa_chain = None
        
    def load_documents(self, file_paths: List[str] = None):
        """
        Load documents from the data directory
        """
        documents = []
        
        # If specific files provided, load them
        if file_paths:
            for file_path in file_paths:
                docs = self._load_single_document(file_path)
                documents.extend(docs)
        else:
            # Load all documents from data directory
            for root, dirs, files in os.walk(Config.DATA_DIR):
                for file in files:
                    file_path = os.path.join(root, file)
                    docs = self._load_single_document(file_path)
                    documents.extend(docs)
        
        # Split documents into chunks
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=Config.CHUNK_SIZE,
            chunk_overlap=Config.CHUNK_OVERLAP,
            separators=["\n\n", "\n", " ", ""]
        )
        
        chunks = text_splitter.split_documents(documents)
        
        # Create or update vectorstore
        self.vectorstore = Chroma.from_documents(
            documents=chunks,
            embedding=self.embeddings,
            persist_directory=Config.VECTORSTORE_DIR
        )
        
        # Create QA chain
        self.qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=self.vectorstore.as_retriever(
                search_kwargs={"k": Config.TOP_K_RESULTS}
            ),
            return_source_documents=True
        )
        
    def _load_single_document(self, file_path: str):
        """
        Load a single document based on its extension
        """
        ext = os.path.splitext(file_path)[1].lower()
        
        try:
            if ext == '.pdf':
                loader = PyPDFLoader(file_path)
            elif ext == '.txt':
                loader = TextLoader(file_path, encoding='utf-8')
            elif ext == '.docx':
                loader = Docx2txtLoader(file_path)
            elif ext == '.ps1':
                loader = PythonLoader(file_path)
            else:
                return []
                
            return loader.load()
            
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            return []
    
    def search_documents(self, query: str) -> Dict:
        """
        Search documents using RAG
        """
        if not self.qa_chain:
            self.load_documents()
            
        result = self.qa_chain({"query": query})
        
        return {
            "answer": result['result'],
            "sources": [
                {
                    "content": doc.page_content[:200] + "...",
                    "metadata": doc.metadata
                }
                for doc in result['source_documents']
            ]
        }
    
    def add_documents(self, file_paths: List[str]):
        """
        Add new documents to the existing vectorstore
        """
        documents = []
        for file_path in file_paths:
            docs = self._load_single_document(file_path)
            documents.extend(docs)
        
        if documents and self.vectorstore:
            self.vectorstore.add_documents(documents)
            self.vectorstore.persist()