import requests
from bs4 import BeautifulSoup
from typing import List, Dict
import json
from langchain.tools import DuckDuckGoSearchResults
from langchain.utilities import DuckDuckGoSearchAPIWrapper

class WebSearchEngine:
    def __init__(self):
        self.search_wrapper = DuckDuckGoSearchAPIWrapper()
        self.search = DuckDuckGoSearchResults(api_wrapper=self.search_wrapper)
        
    def search_installation_params(self, query: str) -> List[Dict[str, str]]:
        """
        Search for silent installation parameters online
        """
        try:
            # Enhanced search query for packaging
            enhanced_query = f"{query} silent installation parameters command line switches"
            
            # Perform search
            results = self.search.results(enhanced_query, num_results=5)
            
            formatted_results = []
            for result in results:
                # Scrape additional content from the webpage
                content = self._scrape_webpage_content(result['link'])
                
                formatted_results.append({
                    'title': result['title'],
                    'link': result['link'],
                    'snippet': result['snippet'],
                    'content': content
                })
            
            return formatted_results
            
        except Exception as e:
            print(f"Web search error: {e}")
            return []
    
    def _scrape_webpage_content(self, url: str) -> str:
        """
        Scrape main content from webpage
        """
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=5)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Get text
            text = soup.get_text()
            
            # Clean up whitespace
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = ' '.join(chunk for chunk in chunks if chunk)
            
            # Limit content length
            return text[:2000] + "..." if len(text) > 2000 else text
            
        except Exception as e:
            return f"Could not scrape content: {str(e)}"
    
    def get_installation_params_from_faqs(self, installer_type: str, app_name: str) -> List[Dict]:
        """
        Get installation parameters from known FAQ sources
        """
        faq_sources = [
            "https://www.itninja.com/software",
            "https://www.silentinstall.org",
            "https://www.advancedinstaller.com/silent-installation-parameters.html"
        ]
        
        results = []
        for source in faq_sources:
            # Implement specific scraping logic for each FAQ source
            # This is simplified - you'd need to adapt per website
            pass
            
        return results