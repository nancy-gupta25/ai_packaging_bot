# backend/web_search.py
import os
import re
import requests

class WebSearchEngine:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "")
        if not self.api_key:
            print("WARNING: No OpenAI API key provided!")

    # ---------------------------
    # Extract Silent Params with Regex
    # ---------------------------
    def extract_silent_params(self, text: str):
        patterns = [
            r"/S\b", r"/silent\b", r"/qn\b", r"/quiet\b",
            r"/VERYSILENT\b", r"/norestart\b", r"-silent\b", r"-q\b"
        ]
        found = set()
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for m in matches:
                found.add(m)
        return list(found)

    # ---------------------------
    # LLM Extraction / Web Search
    # ---------------------------
    def refine_with_openai(self, software_name: str):
        """
        Uses OpenAI to find silent install switches online for the software.
        """
        if not self.api_key:
            return []

        prompt = f"""
You are a software deployment expert.  
Find the exact silent installation switches for {software_name}.  
Return only switches like /S, /quiet, /qn, /VERYSILENT, /norestart, etc.  
If nothing is found, return an empty list.
        """

        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            data = {
                "model": "gpt-3.5-turbo",
                "messages": [
                    {"role": "system", "content": "You extract silent installation switches from reliable web sources."},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0,
                "max_tokens": 150
            }

            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers=headers,
                json=data,
                timeout=15
            )
            if response.status_code == 200:
                result = response.json()
                content = result['choices'][0]['message']['content'].strip()
                # extract switches like /S, /quiet, /qn
                params = re.findall(r"/\w+", content)
                return list(set(params))
            else:
                print(f"OpenAI API error: {response.status_code}")
                return []
        except Exception as e:
            print(f"OpenAI API exception: {e}")
            return []

    # ---------------------------
    # Search Installation Parameters
    # ---------------------------
    def search_installation_params(self, software_name: str):
        """
        Returns silent installation parameters using regex + LLM (web search)
        """
        all_params = []

        # Step 1: Regex extraction is optional if you have page text
        # For web-only search, we can skip regex and directly go to LLM

        # Step 2: Use LLM to fetch web results
        llm_params = self.refine_with_openai(software_name)
        if llm_params:
            all_params.extend(llm_params)

        if all_params:
            return [{
                "title": f"Silent parameters for {software_name}",
                "link": "",
                "parameters": all_params,
                "snippet": f"Found parameters: {', '.join(all_params)}"
            }]
        else:
            # nothing found
            return []