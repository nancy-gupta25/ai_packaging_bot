# backend/app.py
from fastapi import FastAPI, HTTPException 
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import uvicorn

from backend.rag_engine import RAGEngine
from backend.web_search import WebSearchEngine

app = FastAPI(title="Application Packaging Chatbot API")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize engines
rag_engine = RAGEngine()
web_search = WebSearchEngine()

class QueryRequest(BaseModel):
    query: str
    use_web_search: Optional[bool] = True
    use_rag: Optional[bool] = True
    installer_type: Optional[str] = None
    app_name: Optional[str] = None

class QueryResponse(BaseModel):
    answer: str
    sources: List[dict]
    web_results: Optional[List[dict]] = None
    rag_results: Optional[dict] = None

@app.get("/")
async def root():
    return {"message": "Application Packaging Chatbot API"}

@app.post("/query", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    """
    Process user query using RAG and/or LLM Web Search
    """
    try:
        answer_parts = []
        all_sources = []

        # Enhance query with installer type if provided
        software_name = request.app_name.strip() if request.app_name else request.query
        enhanced_query = request.query
        if request.installer_type and request.app_name:
            enhanced_query = f"{request.installer_type} silent installation parameters for {request.app_name}: {request.query}"

        results_found = False

        # --------------------------
        # 1️⃣ RAG Search
        # --------------------------
        if request.use_rag:
            rag_results = rag_engine.search_documents(software_name)
            for chunk in rag_results.get('sources', []):
                content = chunk.get('content','')
                from backend.web_search import WebSearchEngine
                params = WebSearchEngine().extract_silent_params(content)
                if not params:
                    llm_result = WebSearchEngine().refine_with_openai(content, software_name)
                    if "NONE" not in llm_result.upper():
                        params = llm_result.split()
                if params:
                    results_found = True
                    snippet_text = f"Found parameters: {', '.join(params)}"
                    answer_parts.append(f"• {snippet_text} (from internal documentation)")
                    all_sources.append({
                        "title": f"RAG - {software_name}",
                        "link": "",
                        "snippet": snippet_text,
                        "content": content,
                        "parameters": params,
                        "metadata": chunk.get('metadata',{})
                    })

        # --------------------------
        # 2️⃣ Web Search via LLM
        # Only if RAG found nothing
        # --------------------------
        if request.use_web_search and not results_found:
            web_results = WebSearchEngine().search_installation_params(software_name)
            for item in web_results:
                if item.get('parameters'):
                    results_found = True
                    snippet_text = f"Found parameters: {', '.join(item['parameters'])}"
                    answer_parts.append(f"• {snippet_text} (from web search)")
                    all_sources.append(item)
        else:
            web_results = []

        # --------------------------
        # Final Answer
        # --------------------------
        if not results_found:
            final_answer = f"Sorry, I couldn't find any silent installation parameters for {software_name}."
        else:
            final_answer = "\n".join(answer_parts)

        return QueryResponse(
            answer=final_answer,
            sources=all_sources,
            web_results=web_results if web_results else None,
            rag_results=rag_results if request.use_rag else None
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/load-documents")
async def load_documents(file_paths: Optional[List[str]] = None):
    """
    Load documents into RAG database
    """
    try:
        rag_engine.load_documents(file_paths)
        return {"message": "Documents loaded successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)