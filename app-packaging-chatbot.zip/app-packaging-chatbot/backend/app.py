from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import uvicorn

from rag_engine import RAGEngine
from web_search import WebSearchEngine
from config import Config

app = FastAPI(title="Application Packaging Chatbot API")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize engines
rag_engine = RAGEngine()
web_search = WebSearchEngine()

class QueryRequest(BaseModel):
    query: str
    use_web_search: Optional[bool] = True
    use_rag: Optional[bool] = True
    installer_type: Optional[str] = None
    app_name: Optional[str] = None

class QueryResponse(BaseModel):
    answer: str
    sources: List[dict]
    web_results: Optional[List[dict]] = None
    rag_results: Optional[dict] = None

@app.get("/")
async def root():
    return {"message": "Application Packaging Chatbot API"}

@app.post("/query", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    """
    Process user query using RAG and/or web search
    """
    try:
        answer_parts = []
        all_sources = []
        web_results = None
        rag_results = None
        
        # Enhance query based on installer type
        enhanced_query = request.query
        if request.installer_type and request.app_name:
            enhanced_query = f"{request.installer_type} silent installation parameters for {request.app_name}: {request.query}"
        
        # Web Search
        if request.use_web_search:
            web_results = web_search.search_installation_params(enhanced_query)
            if web_results:
                answer_parts.append("Based on online sources:")
                for result in web_results[:3]:
                    answer_parts.append(f"• {result['title']}: {result['snippet']}")
                all_sources.extend(web_results)
        
        # RAG Search
        if request.use_rag:
            rag_results = rag_engine.search_documents(enhanced_query)
            if rag_results:
                answer_parts.append("\nBased on internal documentation:")
                answer_parts.append(rag_results['answer'])
                all_sources.extend(rag_results['sources'])
        
        # Combine answers
        final_answer = "\n".join(answer_parts) if answer_parts else \
            "I couldn't find specific information for your query. Please try rephrasing or providing more details about the application and installer type."
        
        return QueryResponse(
            answer=final_answer,
            sources=all_sources,
            web_results=web_results,
            rag_results=rag_results
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/load-documents")
async def load_documents(file_paths: Optional[List[str]] = None):
    """
    Load documents into RAG database
    """
    try:
        rag_engine.load_documents(file_paths)
        return {"message": "Documents loaded successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)