import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # OpenAI Configuration
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    OPENAI_MODEL = "gpt-4-turbo-preview"
    
    # Paths
    DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
    VECTORSTORE_DIR = os.path.join(os.path.dirname(__file__), "..", "vectorstore")
    
    # RAG Configuration
    CHUNK_SIZE = 1000
    CHUNK_OVERLAP = 200
    TOP_K_RESULTS = 5
    
    # Web Search Configuration
    SEARCH_ENGINE = "duckduckgo"  # or "google", "bing"
    MAX_SEARCH_RESULTS = 3