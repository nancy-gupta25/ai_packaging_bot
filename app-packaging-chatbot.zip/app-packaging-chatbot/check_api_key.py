from openai import OpenAI
 
client = OpenAI(api_key="sk-JPLnjiUSwUqrt9UfSIIEBg")
 
response = client.responses.create(
    model="gpt-4.1-mini",
    input="Hello"
)
 
print(response.output[0].content[0].text)