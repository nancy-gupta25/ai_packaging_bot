class PackagingChatbot {
    constructor() {
        this.apiUrl = 'http://localhost:8000';
        this.initElements();
        this.initEventListeners();
        this.checkHealth();
        this.messageHistory = [];
        this.currentTypingIndicator = null;
    }

    initElements() {
        this.chatMessages = document.getElementById('chatMessages');
        this.userInput = document.getElementById('userInput');
        this.sendButton = document.getElementById('sendButton');
        this.webSearchCheck = document.getElementById('webSearch');
        this.ragSearchCheck = document.getElementById('ragSearch');
        this.installerType = document.getElementById('installerType');
        this.appName = document.getElementById('appName');
        this.sourcesPanel = document.getElementById('sourcesPanel');
        this.sourcesList = document.getElementById('sourcesList');
        this.statusBadge = document.getElementById('statusBadge');
        this.closeSourcesBtn = document.getElementById('closeSourcesBtn');
        this.suggestionBtns = document.querySelectorAll('.suggestion-btn');
        
        // Templates
        this.sourceTemplate = document.getElementById('sourceTemplate');
        this.paramTemplate = document.getElementById('parametersTemplate');
    }

    initEventListeners() {
        this.sendButton.addEventListener('click', () => this.sendMessage());
        this.userInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Auto-resize textarea
        this.userInput.addEventListener('input', () => this.autoResizeTextarea());
        
        // Close sources panel
        if (this.closeSourcesBtn) {
            this.closeSourcesBtn.addEventListener('click', () => {
                this.sourcesPanel.classList.remove('open');
            });
        }
        
        // Suggestion buttons
        this.suggestionBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                this.userInput.value = btn.dataset.query;
                this.sendMessage();
            });
        });
        
        // Check for Ctrl+Enter to send
        this.userInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.ctrlKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Load document status on startup
        this.loadDocumentStatus();
    }

    autoResizeTextarea() {
        this.userInput.style.height = 'auto';
        this.userInput.style.height = (this.userInput.scrollHeight) + 'px';
    }

    async checkHealth() {
        try {
            const response = await fetch(`${this.apiUrl}/health`);
            if (response.ok) {
                const data = await response.json();
                this.updateStatus('connected', `Connected to Ollama (${data.ollama_model})`);
            } else {
                this.updateStatus('disconnected', 'API offline');
            }
        } catch (error) {
            console.error('Health check failed:', error);
            this.updateStatus('disconnected', 'Cannot connect to API');
            this.showConnectionError();
        }
    }

    async loadDocumentStatus() {
        try {
            const response = await fetch(`${this.apiUrl}/status`);
            if (response.ok) {
                const data = await response.json();
                if (data.documents_loaded > 0) {
                    this.showNotification(`📚 ${data.documents_loaded} document chunks loaded`);
                }
            }
        } catch (error) {
            console.error('Failed to load document status:', error);
        }
    }

    updateStatus(status, message) {
        if (!this.statusBadge) return;
        
        const dot = this.statusBadge.querySelector('.status-dot');
        const text = this.statusBadge.querySelector('.status-text');
        
        dot.className = 'status-dot ' + status;
        text.textContent = message;
    }

    showConnectionError() {
        this.addMessage(
            '⚠️ **Connection Error**\n\n' +
            'Cannot connect to the backend API. Please ensure:\n' +
            '• The backend server is running on port 8000\n' +
            '• Ollama is running locally\n' +
            '• You have the correct model installed (llama2, codellama, etc.)',
            'bot'
        );
    }

    showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #3b82f6;
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    async sendMessage() {
        const message = this.userInput.value.trim();
        if (!message) return;

        // Store in history
        this.messageHistory.push({ role: 'user', content: message });

        // Clear input and reset height
        this.userInput.value = '';
        this.userInput.style.height = 'auto';

        // Add user message to chat
        this.addMessage(message, 'user');

        // Show typing indicator
        this.showTypingIndicator();

        try {
            // Prepare query
            const queryData = {
                query: message,
                use_web_search: this.webSearchCheck?.checked ?? true,
                use_rag: this.ragSearchCheck?.checked ?? true,
                installer_type: this.installerType?.value || null,
                app_name: this.appName?.value.trim() || null
            };

            // Log the query for debugging
            console.log('Sending query:', queryData);

            // Send to API with timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

            const response = await fetch(`${this.apiUrl}/query`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(queryData),
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP error ${response.status}`);
            }

            const data = await response.json();

            // Remove typing indicator
            this.hideTypingIndicator();

            // Store response in history
            this.messageHistory.push({ role: 'assistant', content: data.answer });

            // Add bot response
            this.addMessage(data.answer, 'bot');

            // Update sources panel with enhanced display
            this.updateSourcesPanel(data.sources, data.parameters_found);

            // Show parameters if available
            if (data.parameters_found && data.parameters_found.length > 0) {
                this.showParameters(data.parameters_found);
            }

        } catch (error) {
            console.error('Error:', error);
            this.hideTypingIndicator();
            
            if (error.name === 'AbortError') {
                this.addMessage('⏰ Request timeout. The server is taking too long to respond. Please try again.', 'bot');
            } else {
                this.addMessage(`❌ Error: ${error.message}`, 'bot');
            }
        }
    }

    showTypingIndicator() {
        if (this.currentTypingIndicator) {
            this.currentTypingIndicator.remove();
        }
        
        const indicator = document.createElement('div');
        indicator.classList.add('message', 'bot-message', 'typing-message');
        indicator.innerHTML = `
            <div class="message-avatar">🤖</div>
            <div class="message-content">
                <div class="typing-indicator">
                    <span></span><span></span><span></span>
                </div>
            </div>
        `;
        
        this.chatMessages.appendChild(indicator);
        this.scrollToBottom();
        this.currentTypingIndicator = indicator;
    }

    hideTypingIndicator() {
        if (this.currentTypingIndicator) {
            this.currentTypingIndicator.remove();
            this.currentTypingIndicator = null;
        }
    }

    addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${sender}-message`);
        
        // Add avatar
        const avatar = document.createElement('div');
        avatar.classList.add('message-avatar');
        avatar.textContent = sender === 'user' ? '👤' : '🤖';
        messageDiv.appendChild(avatar);
        
        // Add content
        const content = document.createElement('div');
        content.classList.add('message-content');
        
        // Format text with markdown-like syntax
        const formattedText = this.formatMessage(text);
        content.innerHTML = formattedText;
        
        messageDiv.appendChild(content);
        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
        
        return messageDiv;
    }

    formatMessage(text) {
        if (!text) return '';
        
        // Convert markdown-style formatting
        let formatted = text
            // Bold
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            // Italic
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            // Code
            .replace(/`(.*?)`/g, '<code>$1</code>')
            // Bullet points
            .split('\n')
            .map(line => {
                if (line.trim().startsWith('•')) {
                    return `<li>${line.substring(1).trim()}</li>`;
                } else if (line.trim().match(/^\d+\./)) {
                    return `<li class="numbered">${line}</li>`;
                }
                return line;
            })
            .join('<br>');
        
        // Wrap lists
        formatted = formatted.replace(/<li>.*?<\/li>/gs, match => {
            if (match.includes('numbered')) {
                return `<ol>${match}</ol>`;
            }
            return `<ul>${match}</ul>`;
        });
        
        return formatted;
    }

    updateSourcesPanel(sources, parameters) {
        if (!this.sourcesPanel || !this.sourcesList) return;
        
        if (sources && sources.length > 0) {
            this.sourcesPanel.classList.add('open');
            
            // Add parameters summary if available
            let html = '';
            if (parameters && parameters.length > 0) {
                html += `
                    <div class="parameters-summary">
                        <h4>📌 Found Parameters</h4>
                        <div class="parameter-chips">
                            ${parameters.map(p => `<span class="param-chip">${p}</span>`).join('')}
                        </div>
                    </div>
                `;
            }
            
            // Add sources
            html += '<h4>📚 Sources</h4>';
            html += sources.map(source => this.formatSource(source)).join('');
            
            this.sourcesList.innerHTML = html;
        } else {
            this.sourcesList.innerHTML = `
                <div class="empty-state">
                    <p>🔍 No sources found for this query.</p>
                    <p class="hint">Try enabling both search options or being more specific.</p>
                </div>
            `;
        }
    }

    formatSource(source) {
        const title = source.title || 'Source';
        const snippet = source.snippet || source.content || '';
        const params = source.parameters || [];
        const sourceType = source.source_type || source.metadata?.source_type || 'unknown';
        
        // Get icon based on source type
        let icon = '📄';
        if (sourceType.includes('rag')) icon = '📚';
        if (sourceType.includes('web')) icon = '🌐';
        if (sourceType.includes('mock') || sourceType.includes('knowledge')) icon = '🧠';
        
        // Format parameters as chips
        const paramsHtml = params.length > 0 
            ? `<div class="source-params">${params.map(p => `<span class="param">${p}</span>`).join('')}</div>`
            : '';
        
        return `
            <div class="source-item">
                <div class="source-header">
                    <span class="source-icon">${icon}</span>
                    <span class="source-title">${title}</span>
                </div>
                ${paramsHtml}
                <div class="source-snippet">${snippet.substring(0, 150)}${snippet.length > 150 ? '...' : ''}</div>
                ${source.link ? `<a href="${source.link}" target="_blank" class="source-link">View source →</a>` : ''}
                <div class="source-meta">${source.metadata?.file_type || sourceType}</div>
            </div>
        `;
    }

    showParameters(parameters) {
        if (!parameters || parameters.length === 0) return;
        
        // Flash the sources panel to draw attention
        this.sourcesPanel.classList.add('open', 'highlight');
        setTimeout(() => {
            this.sourcesPanel.classList.remove('highlight');
        }, 1000);
    }

    scrollToBottom() {
        this.chatMessages.scrollTo({
            top: this.chatMessages.scrollHeight,
            behavior: 'smooth'
        });
    }

    async loadDocuments() {
        try {
            const response = await fetch(`${this.apiUrl}/load-documents`, {
                method: 'POST'
            });
            
            if (response.ok) {
                const data = await response.json();
                this.showNotification(`✅ ${data.message}`);
            }
        } catch (error) {
            console.error('Failed to load documents:', error);
        }
    }

    clearChat() {
        // Clear chat messages except the first bot message
        while (this.chatMessages.children.length > 1) {
            this.chatMessages.removeChild(this.chatMessages.lastChild);
        }
        
        // Clear message history
        this.messageHistory = [];
        
        // Hide sources panel
        this.sourcesPanel.classList.remove('open');
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.chatbot = new PackagingChatbot();
    
    // Add keyboard shortcut for clearing chat (Ctrl+Shift+C)
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.shiftKey && e.key === 'C') {
            e.preventDefault();
            if (window.chatbot && confirm('Clear chat history?')) {
                window.chatbot.clearChat();
            }
        }
    });
});