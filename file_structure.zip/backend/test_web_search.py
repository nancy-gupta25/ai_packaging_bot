# backend/test_web_search_multi.py
from backend.web_search import WebSearchEngine

def test_silent_parameters(app_list):
    """
    Test LLM web search for multiple apps
    """
    ws = WebSearchEngine()
    
    for app_name in app_list:
        print(f"\n=== Searching silent parameters for {app_name} ===\n")
        results = ws.search_installation_params(app_name)
        
        if results:
            for r in results:
                print("Title:", r.get("title"))
                print("Parameters:", r.get("parameters"))
                print("Snippet:", r.get("snippet"))
                print("-"*60)
        else:
            print(f"No silent installation parameters found for {app_name}.")
            print("-"*60)

if __name__ == "__main__":
    # List of apps you want to test
    apps_to_test = [
        "Ansys",
        "7-Zip",
        "Notepad++",
        "Adobe Reader"
    ]
    test_silent_parameters(apps_to_test)