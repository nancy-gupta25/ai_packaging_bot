import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    # Ollama Configuration
    OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    OLLAMA_LLM_MODEL = os.getenv("OLLAMA_LLM_MODEL", "llama2")  # Options: llama2, codellama, mistral, phi, neural-chat, etc.
    OLLAMA_EMBED_MODEL = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")  # For embeddings if needed later
    
    # LLM Settings
    LLM_TEMPERATURE = 0.1  # Low temperature for consistent results
    LLM_MAX_TOKENS = 500
    LLM_TOP_P = 0.9
    LLM_FREQUENCY_PENALTY = 0
    LLM_PRESENCE_PENALTY = 0
    
    # Paths - Fixed to work cross-platform
    BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # Gets the project root
    DATA_DIR = os.path.join(BASE_DIR, "data")
    VECTORSTORE_DIR = os.path.join(BASE_DIR, "vectorstore")
    
    # Ensure directories exist
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(VECTORSTORE_DIR, exist_ok=True)
    
    # RAG Configuration
    CHUNK_SIZE = 1000
    CHUNK_OVERLAP = 200
    TOP_K_RESULTS = 5
    
    # Document Processing
    SUPPORTED_EXTENSIONS = ['.ps1', '.pdf', '.txt', '.docx', '.md', '.json', '.xml', '.yaml', '.yml']
    MAX_FILE_SIZE_MB = 10  # Skip files larger than this
    
    # Chunking Strategy
    CHUNKING_STRATEGY = "recursive"  # Options: recursive, semantic, fixed
    CHUNKING_SEPARATORS = ["\n\n", "\n", ".", "!", "?", ",", " ", ""]
    
    # Retrieval Settings
    RETRIEVAL_K = 4  # Number of documents to retrieve
    SCORE_THRESHOLD = 0.7  # Similarity score threshold
    USE_MMR = False  # Use Maximum Marginal Relevance for diversity
    MMR_LAMBDA = 0.5  # Trade-off between similarity and diversity
    
    # Web Search Configuration (Simplified - no API keys needed)
    SEARCH_ENGINE = "ollama"  # Using Ollama for intelligent search
    MAX_SEARCH_RESULTS = 3
    ENHANCE_WITH_WEB = False  # Set to True if you want to simulate web search with Ollama
    
    # Installation Parameter Patterns
    SILENT_PARAM_PATTERNS = [
        r'/S\b', r'/silent\b', r'/qn\b', r'/quiet\b',
        r'/VERYSILENT\b', r'/norestart\b', r'-silent\b', r'-q\b',
        r'/qb\b', r'/passive\b', r'/noprogress\b', r'/install\b',
        r'--silent\b', r'--quiet\b', r'-y\b', r'--yes\b',
        r'/sp-\b', r'/suppressmsgboxes\b', r'/verysilent\b',
        r'/SILENT\b', r'/VERYSILENT\b', r'/SUPPRESSMSGBOXES\b',
        r'/NORESTART\b', r'/NOCANCEL\b', r'/FORCECLOSEAPPLICATIONS\b',
        r'/LOADINF\b', r'/SAVEINF\b', r'/LOG\b', r'/L\b',
        r'/v"\?qn"\?', r'/v"\?qb"\?', r'/v"\?passive"\?',
        r'--mode=silent', r'--mode=quiet', r'--mode=unattended',
    ]
    
    # Installer Type Detection Patterns
    INSTALLER_PATTERNS = {
        'msi': [r'\.msi\b', r'msiexec', r'/i\s+\S+\.msi'],
        'installshield': [r'InstallShield', r'/s\b', r'/f1\b', r'/f2\b'],
        'inno_setup': [r'Inno Setup', r'/VERYSILENT', r'/SUPPRESSMSGBOXES'],
        'nsis': [r'NSIS', r'/S\b', r'_??'],
        'wise': [r'Wise', r'/s\b'],
        'exe_installer': [r'\.exe\b', r'setup\.exe', r'install\.exe'],
    }
    
    # Response Formatting
    MAX_SNIPPET_LENGTH = 300
    INCLUDE_METADATA = True
    HIGHLIGHT_MATCHES = True
    
    @classmethod
    def get_ollama_config(cls):
        """Get Ollama configuration as dictionary"""
        return {
            "base_url": cls.OLLAMA_BASE_URL,
            "model": cls.OLLAMA_LLM_MODEL,
            "temperature": cls.LLM_TEMPERATURE,
            "max_tokens": cls.LLM_MAX_TOKENS,
            "top_p": cls.LLM_TOP_P,
            "frequency_penalty": cls.LLM_FREQUENCY_PENALTY,
            "presence_penalty": cls.LLM_PRESENCE_PENALTY,
        }
    
    @classmethod
    def get_embedding_config(cls):
        """Get embedding configuration"""
        return {
            "base_url": cls.OLLAMA_BASE_URL,
            "model": cls.OLLAMA_EMBED_MODEL,
        }
    
    @classmethod
    def validate_config(cls):
        """Validate configuration settings"""
        issues = []
        
        # Check if Ollama is reachable
        import requests
        try:
            response = requests.get(f"{cls.OLLAMA_BASE_URL}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get('models', [])
                model_names = [m['name'] for m in models]
                
                # Check if configured model is available
                if cls.OLLAMA_LLM_MODEL not in ' '.join(model_names):
                    issues.append(f"Model {cls.OLLAMA_LLM_MODEL} not found in Ollama. Available models: {', '.join(model_names)}")
                
                if cls.OLLAMA_EMBED_MODEL not in ' '.join(model_names):
                    issues.append(f"Embedding model {cls.OLLAMA_EMBED_MODEL} not found in Ollama")
            else:
                issues.append(f"Ollama API returned status {response.status_code}")
        except requests.exceptions.ConnectionError:
            issues.append(f"Cannot connect to Ollama at {cls.OLLAMA_BASE_URL}. Is Ollama running?")
        except Exception as e:
            issues.append(f"Error connecting to Ollama: {e}")
        
        # Check if data directory is writable
        if not os.access(cls.DATA_DIR, os.W_OK):
            issues.append(f"Data directory {cls.DATA_DIR} is not writable")
        
        # Check if vectorstore directory is writable
        if not os.access(cls.VECTORSTORE_DIR, os.W_OK):
            issues.append(f"Vectorstore directory {cls.VECTORSTORE_DIR} is not writable")
        
        return issues
    
    @classmethod
    def print_config_summary(cls):
        """Print configuration summary for debugging"""
        print("\n=== Configuration Summary ===")
        print(f"Ollama URL: {cls.OLLAMA_BASE_URL}")
        print(f"LLM Model: {cls.OLLAMA_LLM_MODEL}")
        print(f"Embedding Model: {cls.OLLAMA_EMBED_MODEL}")
        print(f"Data Directory: {cls.DATA_DIR}")
        print(f"Vectorstore Directory: {cls.VECTORSTORE_DIR}")
        print(f"Supported Extensions: {', '.join(cls.SUPPORTED_EXTENSIONS)}")
        print(f"Chunk Size: {cls.CHUNK_SIZE}")
        print(f"Top K Results: {cls.TOP_K_RESULTS}")
        print("=============================\n")