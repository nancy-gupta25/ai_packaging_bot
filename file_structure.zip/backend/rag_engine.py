from typing import List, Dict, Optional, Any
import re
import os
import glob
from pathlib import Path
from config import Config
import requests

class RAGEngine:
    def __init__(self):
        self.config = Config()
        self.documents = []
        self.document_chunks = []
        
        # Ollama settings
        self.ollama_base_url = self.config.OLLAMA_BASE_URL
        self.ollama_model = self.config.OLLAMA_LLM_MODEL
        
        # Load documents if directory exists
        self.load_documents_from_directory()

    def load_documents_from_directory(self, directory_path: Optional[str] = None):
        """Load all supported documents from the data directory"""
        if directory_path is None:
            directory_path = self.config.DATA_DIR        
        if not os.path.exists(directory_path):
            print(f"Directory {directory_path} does not exist. Creating it...")
            os.makedirs(directory_path, exist_ok=True)
            return
        
        file_paths = []
        for ext in self.config.SUPPORTED_EXTENSIONS:
            pattern = os.path.join(directory_path, f"**/*{ext}")
            file_paths.extend(glob.glob(pattern, recursive=True))
        
        if file_paths:
            self.load_documents(file_paths)
            print(f"Loaded {len(file_paths)} documents")

    def load_documents(self, file_paths: Optional[List[str]] = None):
        """Load documents from file paths"""
        if not file_paths:
            return
        
        self.documents = []  # Reset documents
        for path in file_paths:
            try:
                content = self._read_file_content(path)
                if content:
                    # Split content into chunks for better retrieval
                    chunks = self._chunk_content(content)
                    for i, chunk in enumerate(chunks):
                        self.documents.append({
                            "source": path,
                            "filename": os.path.basename(path),
                            "chunk_id": i,
                            "content": chunk,
                            "file_type": Path(path).suffix.lower()
                        })
                    print(f"Loaded {len(chunks)} chunks from {path}")
            except Exception as e:
                print(f"Error loading {path}: {e}")

    def _read_file_content(self, file_path: str) -> Optional[str]:
        """Read content from different file types"""
        ext = Path(file_path).suffix.lower()
        
        try:
            if ext == '.txt' or ext == '.ps1' or ext == '.md':
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
            elif ext == '.pdf':
                # For PDF files, you'd need PyPDF2 or similar
                # This is a placeholder - you might want to add PDF support
                return f"[PDF content from {file_path}]"
            elif ext == '.docx':
                # For Word files, you'd need python-docx
                # This is a placeholder
                return f"[DOCX content from {file_path}]"
            else:
                return None
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return None

    def _chunk_content(self, content: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
        """Split content into overlapping chunks"""
        words = content.split()
        chunks = []
        
        if len(words) <= chunk_size:
            return [content]
        
        for i in range(0, len(words), chunk_size - overlap):
            chunk = ' '.join(words[i:i + chunk_size])
            chunks.append(chunk)
            
        return chunks

    def extract_silent_params(self, text: str) -> List[str]:
        """Extract silent installation parameters using regex patterns"""
        patterns = [
            r'/S\b', r'/silent\b', r'/qn\b', r'/quiet\b',
            r'/VERYSILENT\b', r'/norestart\b', r'-silent\b', r'-q\b',
            r'/qb\b', r'/passive\b', r'/noprogress\b', r'/install\b',
            r'--silent\b', r'--quiet\b', r'-y\b', r'--yes\b',
            r'/sp-\b', r'/suppressmsgboxes\b', r'/verysilent\b',
            r'/SILENT\b', r'/VERYSILENT\b', r'/SUPPRESSMSGBOXES\b',
            r'/NORESTART\b', r'/NOCANCEL\b', r'/FORCECLOSEAPPLICATIONS\b',
            r'/LOADINF\b', r'/SAVEINF\b', r'/LOG\b', r'/L\b',
            r'/v"\?qn"\?', r'/v"\?qb"\?',  # MSI properties
        ]
        
        found = set()
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for m in matches:
                found.add(m)
        return list(found)

    def call_ollama(self, prompt: str) -> str:
        """Call Ollama API for intelligent analysis"""
        try:
            response = requests.post(
                f"{self.ollama_base_url}/api/generate",
                json={
                    "model": self.ollama_model,
                    "prompt": prompt,
                    "stream": False,
                    "temperature": 0.1,
                    "max_tokens": 300
                },
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return result.get('response', '').strip()
            else:
                print(f"Ollama API error: {response.status_code}")
                return ""
        except Exception as e:
            print(f"Ollama API exception: {e}")
            return ""

    def analyze_with_ollama(self, content: str, query: str) -> Dict[str, Any]:
        """Use Ollama to analyze content for installation parameters"""
        prompt = f"""You are an expert in software deployment and application packaging.
        
Task: Analyze the following content and extract ALL silent installation parameters or switches mentioned.

Content:
{content[:1500]}  # Limit content to avoid token limits

Instructions:
1. Identify all silent installation switches (like /S, /quiet, /qn, etc.)
2. Note the installer type if detectable (MSI, InstallShield, NSIS, Inno Setup, etc.)
3. Extract any deployment commands or scripts
4. Return the information in a structured format

Analysis:"""

        response = self.call_ollama(prompt)
        
        # Extract parameters using both regex and LLM
        regex_params = self.extract_silent_params(content)
        llm_params = re.findall(r'[/-]{1,2}\w+', response) if response else []
        
        # Combine and deduplicate
        all_params = list(set(regex_params + llm_params))
        
        return {
            "parameters": all_params,
            "analysis": response,
            "has_params": len(all_params) > 0
        }

    def search_documents(self, query: str) -> Dict[str, Any]:
        """Search documents for installation parameters"""
        if not self.documents:
            return {
                "answer": "No documents loaded. Please load documents first.",
                "sources": []
            }
        
        # Simple keyword-based search (can be enhanced with embeddings later)
        query_terms = query.lower().split()
        relevant_chunks = []
        
        for doc in self.documents:
            content_lower = doc["content"].lower()
            
            # Check if any query term matches
            if any(term in content_lower for term in query_terms):
                # Extract parameters from this chunk
                params = self.extract_silent_params(doc["content"])
                
                if params:  # Only include if we found parameters
                    relevant_chunks.append({
                        "doc": doc,
                        "params": params,
                        "relevance": sum(term in content_lower for term in query_terms)
                    })
        
        # Sort by relevance
        relevant_chunks.sort(key=lambda x: x["relevance"], reverse=True)
        
        # Format sources
        sources = []
        all_params = set()
        
        for chunk in relevant_chunks[:5]:  # Top 5 most relevant
            doc = chunk["doc"]
            params = chunk["params"]
            all_params.update(params)
            
            # Create snippet (first 200 chars)
            snippet = doc["content"][:200] + "..." if len(doc["content"]) > 200 else doc["content"]
            
            sources.append({
                "title": f"{doc['filename']} (Section {doc['chunk_id'] + 1})",
                "link": doc["source"],
                "snippet": snippet,
                "parameters": params,
                "metadata": {
                    "file_type": doc["file_type"],
                    "chunk": doc["chunk_id"] + 1
                }
            })
        
        # Use Ollama for deeper analysis if we have sources
        answer = ""
        if sources:
            # Combine content from top sources for analysis
            combined_content = "\n\n".join([s["snippet"] for s in sources[:3]])
            analysis = self.analyze_with_ollama(combined_content, query)
            
            if analysis["parameters"]:
                all_params.update(analysis["parameters"])
            
            answer = f"Found {len(sources)} relevant document(s) with {len(all_params)} unique silent parameters.\n\n"
            answer += f"Parameters found: {', '.join(sorted(all_params))}\n\n"
            
            if analysis["analysis"]:
                answer += f"Analysis: {analysis['analysis']}"
        else:
            answer = f"No silent installation parameters found for '{query}' in the loaded documents."
        
        return {
            "answer": answer,
            "sources": sources,
            "all_parameters": list(sorted(all_params))
        }

    def refine_with_ollama(self, content: str, software_name: str) -> str:
        """Refine content to extract installation parameters (for web_search compatibility)"""
        prompt = f"""Extract all silent installation parameters for {software_name} from the following text.
Return only the installation switches (like /S, /quiet, /qn, etc.) as a space-separated list.
If no parameters are found, return "NONE".

Text: {content[:1000]}

Silent installation parameters:"""

        return self.call_ollama(prompt)

    def get_document_summary(self) -> Dict[str, Any]:
        """Get summary of loaded documents"""
        if not self.documents:
            return {"status": "No documents loaded"}
        
        file_types = {}
        for doc in self.documents:
            ft = doc["file_type"]
            file_types[ft] = file_types.get(ft, 0) + 1
        
        return {
            "total_chunks": len(self.documents),
            "unique_files": len(set(d["source"] for d in self.documents)),
            "file_types": file_types
        }