from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import uvicorn
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import engines
from rag_engine import RAGEngine
from web_search import WebSearchEngine
from config import Config

# Initialize FastAPI app
app = FastAPI(
    title="Application Packaging Chatbot API",
    description="RAG-powered chatbot for application packaging silent installation parameters",
    version="1.0.0"
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize engines
try:
    rag_engine = RAGEngine()
    web_search = WebSearchEngine()
    logger.info("Engines initialized successfully")
    
    # Validate configuration
    config_issues = Config.validate_config()
    if config_issues:
        for issue in config_issues:
            logger.warning(f"Configuration issue: {issue}")
    else:
        logger.info("Configuration validated successfully")
        
except Exception as e:
    logger.error(f"Failed to initialize engines: {e}")
    raise

# Pydantic models
class QueryRequest(BaseModel):
    query: str
    use_web_search: Optional[bool] = True
    use_rag: Optional[bool] = True
    installer_type: Optional[str] = None
    app_name: Optional[str] = None

class QueryResponse(BaseModel):
    answer: str
    sources: List[Dict[str, Any]]
    web_results: Optional[List[Dict[str, Any]]] = None
    rag_results: Optional[Dict[str, Any]] = None
    parameters_found: Optional[List[str]] = None

class DocumentLoadResponse(BaseModel):
    message: str
    documents_loaded: int
    file_types: Dict[str, int]

class StatusResponse(BaseModel):
    status: str
    ollama_connected: bool
    documents_loaded: int
    config: Dict[str, Any]

# Health check endpoint
@app.get("/health")
async def health_check():
    """Check if the API is healthy"""
    return {
        "status": "healthy",
        "ollama_url": Config.OLLAMA_BASE_URL,
        "ollama_model": Config.OLLAMA_LLM_MODEL
    }

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Application Packaging Chatbot API",
        "version": "1.0.0",
        "endpoints": {
            "GET /": "This info",
            "GET /health": "Health check",
            "GET /status": "Detailed status",
            "POST /query": "Query for silent installation parameters",
            "POST /load-documents": "Load documents into RAG",
            "GET /documents": "List loaded documents"
        }
    }

@app.get("/status", response_model=StatusResponse)
async def get_status():
    """Get detailed status of the API and its components"""
    try:
        # Check Ollama connection
        import requests
        ollama_connected = False
        try:
            response = requests.get(f"{Config.OLLAMA_BASE_URL}/api/tags", timeout=5)
            ollama_connected = response.status_code == 200
        except:
            pass
        
        # Get document summary
        doc_summary = rag_engine.get_document_summary() if hasattr(rag_engine, 'get_document_summary') else {"total_chunks": 0}
        
        return StatusResponse(
            status="running",
            ollama_connected=ollama_connected,
            documents_loaded=doc_summary.get("total_chunks", 0),
            config={
                "ollama_model": Config.OLLAMA_LLM_MODEL,
                "data_dir": Config.DATA_DIR,
                "supported_extensions": Config.SUPPORTED_EXTENSIONS
            }
        )
    except Exception as e:
        logger.error(f"Status check failed: {e}")
        return StatusResponse(
            status="error",
            ollama_connected=False,
            documents_loaded=0,
            config={}
        )

@app.post("/query", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    """
    Process user query using RAG and/or Ollama-powered search
    """
    try:
        logger.info(f"Processing query: {request.query}")
        
        answer_parts = []
        all_sources = []
        all_parameters = set()

        # Determine software name
        software_name = request.app_name.strip() if request.app_name else request.query
        enhanced_query = request.query
        
        if request.installer_type and request.app_name:
            enhanced_query = f"{request.installer_type} silent installation parameters for {request.app_name}: {request.query}"
            logger.info(f"Enhanced query with installer type: {enhanced_query}")

        results_found = False

        # --------------------------
        # 1️⃣ RAG Search
        # --------------------------
        if request.use_rag:
            logger.info("Performing RAG search...")
            try:
                rag_results = rag_engine.search_documents(software_name)
                
                # Process RAG results
                for source in rag_results.get('sources', []):
                    content = source.get('snippet', '')
                    
                    # Try to extract parameters using multiple methods
                    params = []
                    
                    # Method 1: Regex extraction
                    regex_params = web_search.extract_silent_params(content)
                    params.extend(regex_params)
                    
                    # Method 2: Ollama refinement (if no params found or for verification)
                    if not params:
                        logger.info(f"No regex params found, trying Ollama for {software_name}")
                        llm_result = web_search.refine_with_ollama(software_name)
                        if llm_result and "NONE" not in llm_result.upper():
                            params = llm_result
                    
                    if params:
                        results_found = True
                        all_parameters.update(params)
                        snippet_text = f"Found parameters: {', '.join(params)}"
                        answer_parts.append(f"• {snippet_text} (from internal documentation)")
                        
                        all_sources.append({
                            "title": source.get('title', f"Documentation for {software_name}"),
                            "link": source.get('link', ''),
                            "snippet": snippet_text,
                            "content": content[:200] + "..." if len(content) > 200 else content,
                            "parameters": params,
                            "source_type": "rag",
                            "metadata": source.get('metadata', {})
                        })
                
                logger.info(f"RAG search found {len(all_sources)} relevant sources")
                
            except Exception as e:
                logger.error(f"RAG search failed: {e}")
                rag_results = {"sources": []}

        # --------------------------
        # 2️⃣ Web Search via Ollama
        # Only if RAG found nothing or if explicitly requested
        # --------------------------
        if request.use_web_search and (not results_found or len(all_parameters) < 2):
            logger.info(f"Performing web search via Ollama for {software_name}...")
            try:
                web_results = web_search.search_installation_params(software_name)
                
                for item in web_results:
                    if item.get('parameters'):
                        results_found = True
                        params = item['parameters']
                        all_parameters.update(params)
                        snippet_text = f"Found parameters: {', '.join(params)}"
                        answer_parts.append(f"• {snippet_text} (from knowledge base)")
                        
                        all_sources.append({
                            "title": item.get('title', f"{software_name} Installation Guide"),
                            "link": item.get('link', ''),
                            "snippet": item.get('snippet', snippet_text),
                            "parameters": params,
                            "source_type": item.get('source', 'knowledge_base')
                        })
                
                logger.info(f"Web search found {len(web_results)} results")
                
            except Exception as e:
                logger.error(f"Web search failed: {e}")
                web_results = []
        else:
            web_results = []

        # --------------------------
        # Final Answer Construction
        # --------------------------
        if not results_found:
            final_answer = f"I couldn't find any silent installation parameters for {software_name}. Here are some suggestions:\n\n"
            final_answer += "• Try checking the software's official documentation\n"
            final_answer += "• Look for a 'Deployment Guide' or 'Enterprise Installation' section\n"
            final_answer += "• Common parameters to try: /S, /silent, /quiet, /qn, /verysilent\n"
            final_answer += "• You can also try loading relevant documentation into the RAG system"
        else:
            final_answer = "\n".join(answer_parts)
            if all_parameters:
                final_answer += f"\n\n📋 Summary of parameters found: {', '.join(sorted(all_parameters))}"

        return QueryResponse(
            answer=final_answer,
            sources=all_sources,
            web_results=web_results if web_results else None,
            rag_results=rag_results if request.use_rag and 'sources' in rag_results else None,
            parameters_found=sorted(list(all_parameters)) if all_parameters else None
        )

    except Exception as e:
        logger.error(f"Error processing query: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/load-documents", response_model=DocumentLoadResponse)
async def load_documents(background_tasks: BackgroundTasks, file_paths: Optional[List[str]] = None):
    """
    Load documents into RAG database
    """
    try:
        logger.info("Loading documents...")
        
        # If no file paths provided, load from default data directory
        if not file_paths:
            # Load all supported files from data directory
            data_dir = Config.DATA_DIR
            if os.path.exists(data_dir):
                file_paths = []
                for ext in Config.SUPPORTED_EXTENSIONS:
                    import glob
                    pattern = os.path.join(data_dir, f"**/*{ext}")
                    file_paths.extend(glob.glob(pattern, recursive=True))
                logger.info(f"Found {len(file_paths)} files in data directory")
            else:
                os.makedirs(data_dir, exist_ok=True)
                return DocumentLoadResponse(
                    message=f"Data directory {data_dir} created. Please add documents and try again.",
                    documents_loaded=0,
                    file_types={}
                )
        
        # Load documents in background to avoid timeout
        background_tasks.add_task(rag_engine.load_documents, file_paths)
        
        # Get file type statistics
        file_types = {}
        for path in file_paths:
            ext = os.path.splitext(path)[1].lower()
            file_types[ext] = file_types.get(ext, 0) + 1
        
        return DocumentLoadResponse(
            message=f"Started loading {len(file_paths)} documents in the background",
            documents_loaded=len(file_paths),
            file_types=file_types
        )
        
    except Exception as e:
        logger.error(f"Error loading documents: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/documents")
async def list_documents():
    """List all loaded documents"""
    try:
        summary = rag_engine.get_document_summary() if hasattr(rag_engine, 'get_document_summary') else {"total_chunks": 0}
        return JSONResponse(content=summary)
    except Exception as e:
        logger.error(f"Error listing documents: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/documents")
async def clear_documents():
    """Clear all loaded documents"""
    try:
        rag_engine.documents = []
        rag_engine.document_chunks = []
        logger.info("Documents cleared")
        return {"message": "All documents cleared successfully"}
    except Exception as e:
        logger.error(f"Error clearing documents: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.on_event("startup")
async def startup_event():
    """Run on application startup"""
    logger.info("Starting up Application Packaging Chatbot API")
    logger.info(f"Ollama URL: {Config.OLLAMA_BASE_URL}")
    logger.info(f"Model: {Config.OLLAMA_LLM_MODEL}")
    logger.info(f"Data directory: {Config.DATA_DIR}")
    
    # Auto-load documents from data directory on startup
    if os.path.exists(Config.DATA_DIR):
        logger.info("Auto-loading documents from data directory...")
        rag_engine.load_documents_from_directory()

@app.on_event("shutdown")
async def shutdown_event():
    """Run on application shutdown"""
    logger.info("Shutting down Application Packaging Chatbot API")

if __name__ == "__main__":
    # Print config summary on startup
    Config.print_config_summary()
    
    # Run the app
    uvicorn.run(
        "app:app",  # This is correct when running from backend directory
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )