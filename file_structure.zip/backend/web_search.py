import asyncio
import requests
from bs4 import BeautifulSoup
import urllib.parse
import subprocess
import re
import logging
import trafilatura
from concurrent.futures import ThreadPoolExecutor

# Optional: duckduckgo-search library for reliable API access
try:
    from duckduckgo_search import DDGS
    DUCKDUCKGO_AVAILABLE = True
except ImportError:
    DUCKDUCKGO_AVAILABLE = False
    logging.warning("duckduckgo-search not installed. Falling back to HTML scraping only.")

# ---------------------------
# Logging setup
# ---------------------------
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class WebSearchEngine:
    """
    A class to search for silent installation parameters of a given software.
    """

    def __init__(self):
        # Common silent installation patterns (expanded)
        self.COMMON_PARAMS = [
            r"/S\b", r"/silent\b", r"/qn\b", r"/quiet\b", r"/VERYSILENT\b",
            r"/SUPPRESSMSGBOXES\b", r"/SP-\b", r"/norestart\b", r"/passive\b",
            r"--silent\b", r"-silent\b", r"-q\b", r"-y\b", r"/qb\b", r"/noprogress\b",
            r"INSTALLDIR=", r"TARGETDIR=", r"/log\b", r"/LOG\b", r"/lv\b", r"/l\*v\b"
        ]

        # Session for connection reuse
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})

        # Timeout settings
        self.per_url_timeout = 5      # seconds for each URL fetch
        self.global_timeout = 15      # maximum total search time

        # Thread pool for async offloading
        self.executor = ThreadPoolExecutor(max_workers=1)

        # Maximum number of result sources to return
        self.max_sources = 3

    # ---------------------------
    # DuckDuckGo Search (hybrid)
    # ---------------------------
    def search_duckduckgo(self, query: str):
        """
        Search DuckDuckGo and return a list of real result URLs (max 3).
        """
        urls = self._search_duckduckgo_html(query)
        if not urls and DUCKDUCKGO_AVAILABLE:
            logger.info("HTML scraping returned no results; trying duckduckgo-search library...")
            urls = self._search_duckduckgo_api(query)
        return urls[:3]  # Limit to 3 URLs max

    def _search_duckduckgo_html(self, query: str):
        """HTML scraping method with improved selectors."""
        encoded_query = urllib.parse.quote(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded_query}"

        try:
            response = self.session.get(url, timeout=self.per_url_timeout)
            response.raise_for_status()
        except Exception as e:
            logger.error(f"DuckDuckGo HTML request failed: {e}")
            return []

        soup = BeautifulSoup(response.text, "html.parser")
        real_urls = []

        # Multiple selectors
        selectors = [
            ('a', {'class': 'result__a'}),
            ('a', {'class': 'result-link'}),
            ('h2', {'class': 'result__title'}),
            ('a', {'rel': 'nofollow'}),
        ]

        for tag, attrs in selectors:
            elements = soup.find_all(tag, attrs=attrs)
            for elem in elements:
                if tag == 'h2':
                    a = elem.find('a')
                    href = a.get('href') if a else None
                else:
                    href = elem.get('href')
                if not href:
                    continue

                parsed = urllib.parse.urlparse(href)
                query_params = urllib.parse.parse_qs(parsed.query)
                real_url = query_params.get("uddg", [None])[0]
                if real_url:
                    real_urls.append(real_url)
                elif href.startswith("http") and "duckduckgo.com" not in href:
                    real_urls.append(href)

            if real_urls:
                break

        # Fallback: all external links
        if not real_urls:
            all_links = soup.find_all('a', href=True)
            for a in all_links:
                href = a['href']
                if href.startswith('http') and 'duckduckgo.com' not in href:
                    real_urls.append(href)
                    if len(real_urls) >= 3:
                        break

        # Deduplicate
        seen = set()
        unique = []
        for u in real_urls:
            if u not in seen:
                seen.add(u)
                unique.append(u)
        return unique

    def _search_duckduckgo_api(self, query: str):
        """Use duckduckgo-search library for reliable results."""
        try:
            with DDGS() as ddgs:
                results = []
                for r in ddgs.text(query, max_results=3):
                    url = r.get('href')
                    if url and url not in results:
                        results.append(url)
                return results
        except Exception as e:
            logger.error(f"DuckDuckGo API error: {e}")
            return []

    # ---------------------------
    # Regex Extraction
    # ---------------------------
    def extract_silent_params(self, text: str):
        found = set()
        for pattern in self.COMMON_PARAMS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            found.update(matches)
        return list(found)

    # ---------------------------
    # Ollama CLI Extraction
    # ---------------------------
    def refine_with_ollama(self, content: str, software_name: str):
        prompt = f"""You are a software deployment expert. The user is looking for silent installation command-line switches for "{software_name}".

Below is the content of a webpage that may contain installation instructions. Extract any command-line switches or parameters that enable silent/unattended installation. Return only the switches themselves, one per line. If you find none, reply with exactly "NONE".

Examples: /S, /silent, /qn, /quiet, /VERYSILENT, /norestart, INSTALLDIR=C:\Program Files, etc.

Content:
{content[:6000]}
"""
        try:
            result = subprocess.run(
                ["ollama", "run", "llama3"],
                input=prompt.encode("utf-8"),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10
            )
            output = result.stdout.decode("utf-8").strip()
            if not output or "NONE" in output.upper():
                return "NONE"
            return output
        except Exception as e:
            logger.error(f"Ollama error: {e}")
            return "NONE"

    # ---------------------------
    # Synchronous Search (now collects multiple sources)
    # ---------------------------
    def find_silent_parameters(self, software_name: str):
        """
        Synchronous search (blocking). Returns a list of result dictionaries,
        each containing parameters from a different source. At most `max_sources`
        results are returned.
        """
        # Build query variations
        queries = [software_name]
        if not any(kw in software_name.lower() for kw in ['silent', 'install', 'switch', 'command']):
            queries.append(f"{software_name} silent install switches")
            queries.append(f"{software_name} silent installation")

        urls = []
        for q in queries:
            logger.info(f"Searching: {q}")
            urls = self.search_duckduckgo(q)
            if urls:
                break

        if not urls:
            logger.warning("No search results found.")
            return []

        results = []

        # Process URLs until we have enough results or run out of URLs
        for url in urls:
            if len(results) >= self.max_sources:
                break

            print(f"Checking: {url}")
            logger.info(f"Checking: {url}")
            try:
                response = self.session.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=self.per_url_timeout)
                if response.status_code != 200:
                    continue

                page_text = trafilatura.extract(response.text, include_comments=False, include_tables=True, no_fallback=False)
                if not page_text:
                    page_text = response.text

                # Try regex
                params = self.extract_silent_params(page_text)
                if params:
                    results.append({
                        'title': f"Parameters from {url}",
                        'link': url,
                        'snippet': page_text[:200] + "...",
                        'parameters': params,
                        'source': 'regex',
                        'confidence': 'medium'
                    })
                    print(f"Found via regex: {params} at {url}")
                    continue  # Move to next URL (don't use Ollama for this URL)

                # If regex failed, try Ollama
                ollama_output = self.refine_with_ollama(page_text, software_name)
                if ollama_output and "NONE" not in ollama_output.upper():
                    ollama_params = [line.strip() for line in ollama_output.splitlines() if line.strip()]
                    if ollama_params:
                        results.append({
                            'title': f"Ollama-extracted from {url}",
                            'link': url,
                            'snippet': page_text[:200] + "...",
                            'parameters': ollama_params,
                            'source': 'ollama',
                            'confidence': 'low'
                        })
                        print(f"Found via Ollama: {ollama_params} at {url}")

            except Exception as e:
                print(f"Error checking {url}: {e}")
                logger.error(f"Error processing {url}: {e}")
                continue

        if not results:
            print("No silent parameters found.")

        return results

    # ---------------------------
    # Asynchronous Wrapper
    # ---------------------------
    async def async_find_silent_parameters(self, software_name: str):
        """
        Asynchronously run the synchronous search in a thread pool.
        This frees the event loop while waiting.
        """
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(self.executor, self.find_silent_parameters, software_name)
        return result

    # ---------------------------
    # Alias method (synchronous)
    # ---------------------------
    def search_installation_params(self, software_name: str):
        return self.find_silent_parameters(software_name)


# ---------------------------
# Generic CLI runner
# ---------------------------
if __name__ == "__main__":
    software = input("Enter software name: ").strip()
    if software:
        async def main():
            engine = WebSearchEngine()
            results = await engine.async_find_silent_parameters(software)
            print("\nResults:\n")
            if results:
                for i, res in enumerate(results, 1):
                    print(f"{i}. Source: {res['link']} (via {res['source']})")
                    print(f"   Parameters: {', '.join(res['parameters'])}")
                    print()
            else:
                print("No parameters found.")
        asyncio.run(main())
    else:
        print("No software name provided.")