async function send(){
 let input=document.getElementById("userInput");
 let msg=input.value;
 let res=await fetch("http://127.0.0.1:8000/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:msg})});
 let data=await res.json();
 document.getElementById("messages").innerHTML+="<p><b>You:</b>"+msg+"</p><p><b>Bot:</b>"+JSON.stringify(data)+"</p>";
 input.value="";
}
