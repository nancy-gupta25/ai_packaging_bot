from fastapi import FastAPI
from pydantic import BaseModel
from rag_pipeline import create_qa
from silent_switch_agent import get_silent_switch_llm

app = FastAPI()
qa_chain = create_qa()

class Query(BaseModel):
    message: str

@app.post("/chat")
def chat(q: Query):
    msg = q.message
    if "silent" in msg.lower():
        return {"response": get_silent_switch_llm(msg)}
    return {"response": qa_chain.run(msg)}
