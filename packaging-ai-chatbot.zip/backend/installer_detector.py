import os
def detect_installer(file_name):
    ext = os.path.splitext(file_name)[1].lower()
    if ext == ".msi": return "MSI"
    if ext == ".exe": return "EXE"
    if ext == ".msix": return "MSIX"
    return "UNKNOWN"
