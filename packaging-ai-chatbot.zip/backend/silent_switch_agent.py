import requests
from bs4 import BeautifulSoup
from duckduckgo_search import DDGS
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage

llm = ChatOpenAI(temperature=0)

def search_web(query, max_results=3):
    results = []
    with DDGS() as ddgs:
        for r in ddgs.text(query, max_results=max_results):
            results.append(r["href"])
    return results

def scrape_page(url):
    try:
        res = requests.get(url, timeout=10)
        soup = BeautifulSoup(res.text, "html.parser")
        return soup.get_text()[:4000]
    except:
        return ""

def get_silent_switch_llm(app_name):
    query = f"{app_name} silent install uninstall switches MSI EXE silent parameters"
    links = search_web(query)
    content = ""
    for link in links:
        content += scrape_page(link)

    prompt = f"""You are an Application Packaging expert. Extract silent install and uninstall switches.
CONTENT:{content}"""

    response = llm([HumanMessage(content=prompt)])
    return response.content
