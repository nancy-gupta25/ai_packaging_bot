import os
from langchain.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA

docs = []

def load_docs(folder="knowledge"):
    for root, _, files in os.walk(folder):
        for file in files:
            path = os.path.join(root, file)
            if file.endswith(".pdf"):
                docs.extend(PyPDFLoader(path).load())
            elif file.endswith(".txt") or file.endswith(".ps1"):
                docs.extend(TextLoader(path).load())
            elif file.endswith(".docx"):
                docs.extend(Docx2txtLoader(path).load())
    return docs

def create_qa():
    documents = load_docs()
    embeddings = OpenAIEmbeddings()
    db = FAISS.from_documents(documents, embeddings)
    qa = RetrievalQA.from_chain_type(llm=ChatOpenAI(), retriever=db.as_retriever())
    return qa
