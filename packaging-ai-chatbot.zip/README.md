# AI Packaging Chatbot

pip install -r requirements.txt
uvicorn backend.main:app --reload
